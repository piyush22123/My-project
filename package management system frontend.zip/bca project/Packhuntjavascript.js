
// code that refresh the page when download button is clicked

document.querySelector('.submitbtn').addEventListener('click', function() {
    location.reload();
});

// code to uncheck the checkbox when cliking the download button
document.querySelector('.submitbtn').addEventListener('click', function() {
	const checkboxes = document.querySelectorAll('.js-homepage-app-checkbox');
	checkboxes.forEach(function(checkbox) {
	  if (checkbox.checked) {
		checkbox.checked = false;
	  }
	});
  });

  
//   code to disable download button until user does not check the checkbox
document.querySelector('.submitbtn').disabled = true;

document.querySelectorAll('.js-homepage-app-checkbox').forEach(function(checkbox) {
  checkbox.addEventListener('change', function() {
    document.querySelector('.submitbtn').disabled = !checkbox.checked;
  });
});






  
  