<?php

// Set database credentials
$dbHost = "localhost";
$dbUser = "root";
$dbPass = "pass@pms2514";
$dbName = "packages";

// Create database connection
$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if a package was selected
if (isset($_POST['package_id'])) {

    // Retrieve the URL of the selected package from the database
    $package_id = $_POST['package_id'];
    $sql = "SELECT url FROM packages WHERE id = $package_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {

        // Get the URL from the result set
        $row = $result->fetch_assoc();
        $url = $row['url'];

        // Download the package file from Google Drive
        $file = file_get_contents($url);
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="package.zip"');
        header('Content-Length: ' . strlen($file));
        echo $file;
        exit;
    }
}

// Close the database connection
$conn->close();

?>
